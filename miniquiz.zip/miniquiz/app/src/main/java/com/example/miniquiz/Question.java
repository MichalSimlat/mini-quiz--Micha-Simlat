package com.example.miniquiz;

public class Question {
    private String text;
    private String answerA;
    private String answerB;
    private String answerC;
    private String correct;

    public Question(String text, String answerA, String answerB, String answerC, String correct) {
        this.text = text;
        this.answerA = answerA;
        this.answerB = answerB;
        this.answerC = answerC;
        this.correct = correct;
    }

    public String getText() { return text; }
    public String getAnswerA() { return answerA; }
    public String getAnswerB() { return answerB; }
    public String getAnswerC() { return answerC; }
    public String getCorrect() { return correct; }
}